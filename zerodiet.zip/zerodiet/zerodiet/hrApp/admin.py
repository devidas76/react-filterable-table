# Register your models here.
from django.contrib import admin
from .models import *


@admin.register(StateMaster)
class StateMasterAdmin(admin.ModelAdmin):
    list_display = (
    'state_id', 'state_name', 'is_active', 'created_by', 'modified_by', 'created_date',
    'modified_date', 'deactivation_reason', 'is_suspended', 'suspension_reason', 'is_audit_required')
    ordering = ['state_id']
    search_fields = ('state_id', 'state_name', 'created_by', 'modified_by')
    list_display_links = (
   'state_id', 'state_name', 'is_active', 'deactivation_reason', 'is_suspended',
    'suspension_reason', 'is_audit_required', 'created_by', 'modified_by')
    fieldsets = (
        ('State Master', {
            'fields': (
           'state_name', 'is_active', 'deactivation_reason', 'is_suspended', 'suspension_reason',
            'is_audit_required', 'created_by', 'modified_by')
        }),
    )
    list_per_page = 25


@admin.register(CityMaster)
class CityMasterAdmin(admin.ModelAdmin):
    list_display = (
    'city_id', 'city_name', 'state_name', 'is_active', 'created_by', 'modified_by', 'created_date',
    'modified_date', 'deactivation_reason', 'is_suspended', 'suspension_reason', 'is_audit_required')
    ordering = ['city_id']
    search_fields = ('city_id', 'city_name', 'state_name', 'created_by', 'modified_by')
    list_display_links = (
     'city_id', 'city_name', 'state_name', 'is_active', 'deactivation_reason', 'is_suspended',
    'suspension_reason', 'is_audit_required', 'created_by', 'modified_by')
    fieldsets = (
        ('City Master', {
            'fields': (
            'city_name', 'state_name','is_active', 'deactivation_reason', 'is_suspended', 'suspension_reason',
            'is_audit_required', 'created_by', 'modified_by')
        }),
    )
    list_per_page = 25






@admin.register(PatientMaster)
class PatientMasterAdmin(admin.ModelAdmin):
    list_display = (
    'patient_id', 'user',  'phone_number','date_of_birth', 'gender',  'height', 'weight','bmi', 'address',  'pincode', 'state_name', 'city_name')
    ordering = ['patient_id']
    search_fields = ('patient_id',  'user',  'phone_number', 'date_of_birth', 'gender',  'height', 'weight', 'bmi','created_by', 'modified_by')
    list_display_links = (
    'patient_id', 'user',  'phone_number', 'date_of_birth', 'gender',  'height', 'weight','bmi', 'address',  'pincode',  'state_name', 'city_name')
    fieldsets = (
        ('Patient Master', {
            'fields': (
           'user',  'phone_number','date_of_birth', 'gender',  'height', 'weight', 'bmi','address', 'pincode', 'state_name', 'city_name')
        }),
    )
    list_per_page = 25



@admin.register(FeedbackMaster)
class FeedbackMasterAdmin(admin.ModelAdmin):
    list_display = (
    'feedback_id', 'feedback_message','feedback_rating', 'feedback_pickup','feedback_delivery', 'feedback_service', 'patient_id',  'is_active','created_by', 'modified_by', 'created_date',
    'modified_date', 'deactivation_reason', 'is_suspended', 'suspension_reason', 'is_audit_required')
    ordering = ['feedback_id']
    search_fields = ('feedback_id', 'created_by', 'modified_by')
    list_display_links = (
    'feedback_id', 'feedback_message','feedback_rating', 'feedback_pickup','feedback_delivery', 'feedback_service', 'patient_id',  'is_active', 'deactivation_reason', 'is_suspended',
    'suspension_reason', 'is_audit_required', 'created_by', 'modified_by')
    fieldsets = (
        ('Feedback Master', {
            'fields': (
             'feedback_message','feedback_rating', 'feedback_pickup','feedback_delivery', 'feedback_service', 'patient_id',  'is_active', 'deactivation_reason', 'is_suspended', 'suspension_reason',
            'is_audit_required', 'created_by', 'modified_by')
        }),
    )
    list_per_page = 25



@admin.register(MedicalMaster)
class MedicalMasterAdmin(admin.ModelAdmin):
    list_display = (
    'medical_id', 'medical_name', 'is_active', 'created_by', 'modified_by', 'created_date',
    'modified_date', 'deactivation_reason', 'is_suspended', 'suspension_reason', 'is_audit_required')
    ordering = ['medical_id']
    search_fields = ('medical_id', 'medical_name', 'created_by', 'modified_by')
    list_display_links = (
   'medical_id', 'medical_name', 'is_active', 'deactivation_reason', 'is_suspended',
    'suspension_reason', 'is_audit_required', 'created_by', 'modified_by')
    fieldsets = (
        ('State Master', {
            'fields': (
           'medical_name', 'is_active', 'deactivation_reason', 'is_suspended', 'suspension_reason',
            'is_audit_required', 'created_by', 'modified_by')
        }),
    )
    list_per_page = 25


@admin.register(DiagnosisMaster)
class DiagnosisMasterAdmin(admin.ModelAdmin):
    list_display = (
    'diagnosis_id', 'diagnosis_name', 'is_active', 'created_by', 'modified_by', 'created_date',
    'modified_date', 'deactivation_reason', 'is_suspended', 'suspension_reason', 'is_audit_required')
    ordering = ['diagnosis_id']
    search_fields = ('diagnosis_id', 'diagnosis_name', 'created_by', 'modified_by')
    list_display_links = (
   'diagnosis_id', 'diagnosis_name', 'is_active', 'deactivation_reason', 'is_suspended',
    'suspension_reason', 'is_audit_required', 'created_by', 'modified_by')
    fieldsets = (
        ('Diagnosis Master', {
            'fields': (
           'diagnosis_name', 'is_active', 'deactivation_reason', 'is_suspended', 'suspension_reason',
            'is_audit_required', 'created_by', 'modified_by')
        }),
    )
    list_per_page = 25


@admin.register(DietMaster)
class DietMasterAdmin(admin.ModelAdmin):
    list_display = (
    'diet_id', 'diet_type','diet_name','diet_value','diet_value_cals', 'is_active', 'created_by', 'modified_by', 'created_date',
    'modified_date', 'deactivation_reason', 'is_suspended', 'suspension_reason', 'is_audit_required')
    ordering = ['diet_id']
    search_fields = ('diet_id',  'diet_type','diet_name','diet_value','diet_value_cals', 'created_by', 'modified_by')
    list_display_links = (
   'diet_id', 'diet_type','diet_name','diet_value','diet_value_cals', 'is_active', 'deactivation_reason', 'is_suspended',
    'suspension_reason', 'is_audit_required', 'created_by', 'modified_by')
    fieldsets = (
        ('Diet Master', {
            'fields': (
           'diet_type','diet_name','diet_value','diet_value_cals', 'is_active', 'deactivation_reason', 'is_suspended', 'suspension_reason',
            'is_audit_required', 'created_by', 'modified_by')
        }),
    )
    list_per_page = 25


@admin.register(VideoUpload)
class VideoUploadAdmin(admin.ModelAdmin): 
    list_display = (
    'video_id', 'video_title', 'video_name', 'is_active', 'created_by', 'modified_by', 'created_date',
    'modified_date', 'deactivation_reason', 'is_suspended', 'suspension_reason', 'is_audit_required')
    ordering = ['video_id']
    search_fields = ('video_id', 'video_title', 'video_name', 'created_by', 'modified_by')
    list_display_links = (
   'video_id', 'video_title', 'video_name', 'is_active', 'deactivation_reason', 'is_suspended',
    'suspension_reason', 'is_audit_required', 'created_by', 'modified_by')
    fieldsets = (
        ('Diet Master', {
            'fields': (
           'video_title', 'video_name', 'is_active', 'deactivation_reason', 'is_suspended', 'suspension_reason',
            'is_audit_required', 'created_by', 'modified_by')
        }),
    )
    list_per_page = 25