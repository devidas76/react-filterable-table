from enum import Enum


class DietType(Enum):
	awaking = 'Awaking'
	breakfast = 'BreakFast'
	lunch = 'Lunch'
	midday = 'MidDay'
	dinner = 'Dinner'
	night = 'Night'
    
   