from django.db import models

# Create your models here.
from django.contrib.auth.models import User
from django.core.validators import RegexValidator
from django.core.exceptions import ValidationError
from django.utils.crypto import get_random_string
from django.contrib.postgres.fields import ArrayField
from multiselectfield import MultiSelectField
#from django.contrib.auth.models import AbstractUser
# Create your models here.
from .constants import *

class Base(models.Model):
    is_active = models.BooleanField(default=True)
    deactivation_reason = models.CharField(max_length=256, blank=True, null=True, default=None)
    is_suspended = models.BooleanField(default=False)
    suspension_reason = models.CharField(max_length=256, blank=True, null=True, default=None)
    is_audit_required = models.BooleanField(default=False)
    created_by = models.CharField(max_length=200, blank=True, null=True, default=None)
    created_date = models.DateTimeField(auto_now_add=True, blank=True, null=True, editable=False)
    modified_by = models.CharField(max_length=200, blank=True, null=True, default=None)
    modified_date = models.DateTimeField(auto_now=True, blank=True, null=True, editable=False)


    class Meta:
        abstract = True

class StateMaster(Base):
	state_id = models.CharField(max_length=16, blank=True, null=True, editable=False, unique=True)
	state_name = models.CharField(max_length=40,blank=False, null=False, default=None,unique=True)

	class Meta:
		db_table = 'dt_state_master'
		verbose_name = "State Master"
		verbose_name_plural = "State Master"

	def save(self, **kwargs):
		if not self.state_id:
			self.state_id = get_random_string(length=6)
		super(StateMaster, self).save(**kwargs)

	def __str__(self):
		return str(self.state_name)


class CityMaster(Base):
	city_id = models.CharField(max_length=16, blank=True, null=True, editable=False, unique=True)
	city_name = models.CharField(max_length=16, blank=True, null=True, default=None , unique=True)
	state_name= models.ForeignKey(StateMaster, to_field="state_id", on_delete=models.CASCADE, blank=True, null=True, default=None)

	class Meta:
		db_table = 'dz_city_master'
		verbose_name = "City Master"
		verbose_name_plural = "City Master"

	def save(self, **kwargs):
		if not self.city_id:
			self.city_id = get_random_string(length=6)
		super(CityMaster, self).save(**kwargs)

	def __str__(self):
		return str(self.city_name)


class PatientMaster(models.Model):
	patient_id = models.CharField(max_length=16, blank=True, null=True, editable=False, unique=True)
	user = models.OneToOneField(User, on_delete=models.SET_NULL, null=True, blank=True)
	phone_number = models.CharField(max_length=10, blank=True, null=True, default=None)
	date_of_birth = models.CharField(max_length=10, blank=True, null=True, default=None)
	gender = models.CharField(max_length=10, blank=True, null=True, default=None)
	height = models.CharField(max_length=10, blank=True, null=True, default=None)
	weight = models.CharField(max_length=10, blank=True, null=True, default=None)
	bmi = models.CharField(max_length=10, blank=True, null=True, default=None)
	address = models.CharField(max_length=50, blank=True, null=True, default=None)
	pincode = models.CharField(max_length=50, blank=True, null=True, default=None)
	state_name = models.ForeignKey(StateMaster,to_field="state_name",on_delete=models.SET_NULL, blank=True, null=True, default=None)
	city_name = models.ForeignKey(CityMaster,to_field="city_name",on_delete=models.SET_NULL, blank=True, null=True, default=None)
	
	class Meta:
		db_table = 'dt_patient_master'
		verbose_name = "Patient Master"
		verbose_name_plural = "Patient Master"

	def save(self, **kwargs):
		super(PatientMaster, self).save(**kwargs)
		self.patient_id = 'E%04d' % self.pk
		PatientMaster.objects.filter(pk=self.pk).update(patient_id=self.patient_id)

	def __str__(self):
		return u'%s %s' % (self.user.first_name, self.user.last_name)

class FeedbackMaster(Base):
	feedback_id = models.CharField(max_length=16, blank=True, null=True, editable=False, unique=True)
	feedback_rating = models.FloatField(blank=True, null=True, default=None)
	feedback_pickup = models.CharField(max_length=140, blank=True, null=True, default=None)
	feedback_delivery = models.CharField(max_length=140, blank=True, null=True, default=None)
	feedback_service = models.CharField(max_length=140, blank=True, null=True, default=None)
	patient_id = models.ForeignKey(User,to_field="username",on_delete=models.CASCADE, blank=True, null=True, default=None)
	feedback_message = models.TextField(max_length=512, blank=True, null=True, default=None)


	class Meta:
		db_table = 'dz_feedback_master'
		verbose_name = "Feedback Master"
		verbose_name_plural = "Feedback Master"

	def save(self, **kwargs):
		if not self.feedback_id:
			self.feedback_id = get_random_string(length=6)
		super(FeedbackMaster, self).save(**kwargs)
		

class MedicalMaster(Base):
	medical_id = models.CharField(max_length=16, blank=True, null=True, editable=False, unique=True)
	medical_name = models.CharField(max_length=128, blank=True, null=True, default=None)
	
	class Meta:
		db_table = 'dz_medical_master'
		verbose_name = "Medical Master"
		verbose_name_plural = "Medical Master"

	def save(self, **kwargs):
		if not self.medical_id:
			self.medical_id = get_random_string(length=6)
		super(MedicalMaster, self).save(**kwargs)
		
	def __str__(self):
		return str(self.medical_name)

		
class DiagnosisMaster(Base):
	diagnosis_id = models.CharField(max_length=16, blank=True, null=True, editable=False, unique=True)
	diagnosis_name = models.CharField(max_length=128, blank=True, null=True, default=None)
	
	class Meta:
		db_table = 'dt_diagnosis_master'
		verbose_name = "Diagnosis Master"
		verbose_name_plural = "Diagnosis Master"

	def save(self, **kwargs):
		if not self.diagnosis_id:
			self.diagnosis_id = get_random_string(length=6)
		super(DiagnosisMaster, self).save(**kwargs)
		
	def __str__(self):
		return str(self.diagnosis_name)

		
class DietMaster(Base):
	Diet_Type = (
		(1, DietType.awaking.value),
        (2, DietType.breakfast.value),
        (3, DietType.lunch.value),
        (4, DietType.midday.value),
        (5, DietType.dinner.value),
        (6, DietType.night.value),
        
	)
	diet_id = models.CharField(max_length=16, blank=True, null=True, editable=False, unique=True)
	diet_type = models.IntegerField(choices=Diet_Type, blank=False, default=1)
	diet_name = models.CharField(max_length=128, blank=True, null=True, default=None)
	diet_value = models.CharField(max_length=128, blank=True, null=True, default=None)
	diet_value_cals = models.CharField(max_length=128, blank=True, null=True, default=None)
	
	class Meta:
		db_table = 'dt_diet_master'
		verbose_name = "Diet Master"
		verbose_name_plural = "Diet Master"

	def save(self, **kwargs):
		if not self.diet_id:
			self.diet_id = get_random_string(length=6)
		super(DietMaster, self).save(**kwargs)
		
	def __str__(self):
		return str(self.diet_name)

		
class VideoUpload(Base):
	video_id = models.CharField(max_length=16, blank=True, null=True, editable=False, unique=True)
	video_title = models.CharField(max_length=128, blank=True, null=True, default=None)
	video_name = models.FileField(max_length=128, blank=True, null=True)
	
	class Meta:
		db_table = 'dt_video_upload'
		verbose_name = "Video Upload"
		verbose_name_plural = "Video Upload"

	def save(self, **kwargs):
		if not self.video_id:
			self.video_id = get_random_string(length=6)
		super(VideoUpload, self).save(**kwargs)
		
