from .models import *
from rest_framework import serializers, fields
from django.shortcuts import get_object_or_404


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'username', 'first_name', 'last_name', 'email', 'password', 'is_staff', 'is_superuser')



class PatientMasterSerializer(serializers.ModelSerializer):

    user = UserSerializer(required=False, allow_null=True)

    class Meta:
        model = PatientMaster
        fields = '__all__'

    def create(self, validated_data):
        user_data = validated_data.pop('user')
        user = UserSerializer.create(UserSerializer(), validated_data=user_data)
        master, created = UserMaster.objects.update_or_create(user=user,
                                                                  phone_number=validated_data.pop('phone_number'),
                                                                  address_line_1=validated_data.pop(
                                                                      'address_line_1'),address_line_2=validated_data.pop(
                                                                      'address_line_2'), pincode=validated_data.pop(
                                                                      'pincode'))
        return master
    
