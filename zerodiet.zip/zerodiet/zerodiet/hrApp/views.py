from django.shortcuts import render
from . models import *
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.status import HTTP_401_UNAUTHORIZED
#from . serializers import *
from rest_framework.generics import ListAPIView, CreateAPIView, RetrieveUpdateDestroyAPIView
from rest_framework.authtoken.models import Token
from django.contrib.auth.models import Permission
import json
from django.contrib.auth.models import Group
from django.db.models import Q
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework import status
from datetime import date
from datetime import date, timedelta
import datetime
import logging
from django.shortcuts import get_object_or_404
from django.contrib.auth.hashers import make_password ,check_password
import pathlib
import os.path


@api_view(["POST"])
def login_user(request):
    username = request.data.get("username")
    password = request.data.get("password")
    user = authenticate(username=username, password=password)
    request.session['username'] = username

    if user is not None:
        if user.is_active:
            token, created = Token.objects.get_or_create(user=user)
            user_id = token.user_id

            user_permissions = list(Permission.objects.filter(user=user).values())
            user_group = Group.objects.filter(user=user).values()
            user_object = User.objects.filter(id=token.user_id).values('username', 'is_active', 'is_staff',
                                                                       'is_superuser', 'date_joined', 'last_name',
                                                                       'first_name', 'email').get()
            request.session['auth'] = token.key

            return Response(
                {"success": "login successfully", "token": token.key, "user_id": user_id,
                 "user_object": user_object, "list_user_permissions": user_permissions,
                 "user_group": user_group})

    else:
        return Response({"error": "Invalid Username & Password"}, status=HTTP_401_UNAUTHORIZED)


@csrf_exempt
def logout_view(request):
    logout(request)
    return HttpResponse("logout Succesfully")


class PatientMasterListAPIView(ListAPIView):
    queryset = PatientMaster.objects.all()
    serializer_class = PatientMasterSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (TokenAuthentication,)


class PatientMasterRetrieveAPIView(RetrieveUpdateDestroyAPIView):
    queryset = PatientMaster.objects.all()
    serializer_class = PatientMasterSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (TokenAuthentication,)
    lookup_field = 'patient_id'


class PatientMasterCreateAPIView(CreateAPIView):
    queryset = PatientMaster.objects.all()
    serializer_class = PatientMasterSerializer
    permission_classes = (IsAuthenticated,)
   

class PatientMasterCreateApi(APIView):
   
    serializer_class = PatientMasterSerializer

    def post(self, request, *args, **kwargs):
        data = request.data
        user_data = {}
       	patientmaster_data = {}
        user_group = {}
        group_deatils = {}
        response_object = {}

        if 'username' in data:
            user_data['username'] = data['username']
        else:
            return Response("Please Enter Username")
        if 'first_name' in data:
            user_data['first_name'] = data['first_name']

        if 'last_name' in data:
            user_data['last_name'] = data['last_name']

        if 'email' in data:
            user_data['email'] = data['email']

        if 'password' in data:
            hashed_pwd = make_password(data['password'])
            user_data['password'] = hashed_pwd

        if 'is_staff' in data:
            user_data['is_staff'] = data['is_staff']

        if 'is_superuser' in data:
            user_data['is_superuser'] = data['is_superuser']

        # employee_master data
        if 'phone_number' in data:
            patientmaster_data['phone_number'] = data['phone_number']

        if 'date_of_birth' in data:
            patientmaster_data['date_of_birth'] = data['date_of_birth']

        if 'gender' in data:
            patientmaster_data['gender'] = data['gender']

 		if 'height' in data:
            patientmaster_data['height'] = data['height']

        if 'weight' in data:
            patientmaster_data['weight'] = data['weight']

 		if 'bmi' in data:
            patientmaster_data['bmi'] = data['bmi']

        if 'address' in data:
            patientmaster_data['address'] = data['address']

		if 'pincode' in data:
            patientmaster_data['pincode'] = data['pincode']

        if 'state_name' in data:
            patientmaster_data['state_name'] = data['state_name']

		if 'city_name' in data:
            patientmaster_data['city_name'] = data['city_name']

        if User.objects.filter(username=data['username']).exists():
            return Response("A user with that username already exists, Please Select Another Username",
                            status=status.HTTP_200_OK)
        else:


            patientmaster_data['user'] = user_data
            patient_master_serializer = PatientMasterSerializer(data=patientmaster_data)
            if patient_master_serializer.is_valid():
                patient_master_serializer.save()
                patientmaster_data_details = patient_master_serializer.data
                custom_patient_master_id = patient_master_serializer.data['patient_id']
                user_id = patient_master_serializer.data['user']['id']
                username = patient_master_serializer.data['user']['username']

                # save user group
                if "group_name" in data:
                    group_name = data['group_name']
                    if len(group_name) > 0:
                        array_of_group = []
                        for i in range(len(group_name)):
                            if Group.objects.filter(name=group_name[i]).exists():
                                new_group_name = group_name[i]
                                array_of_group.append(group_name[i])
                                my_group = Group.objects.get(name=new_group_name)
                                my_group.user_set.add(user_id)
                            else:
                                return Response("Group name doesn't exists, Please Select Valid Group name",
                                                status=status.HTTP_200_OK)
                        group_deatils['patient_id'] = custom_patient_master_id
                        group_deatils['user_id'] = user_id
                        group_deatils['username'] = username
                        group_deatils['group_name'] = array_of_group
                response_object['user_group_details'] = group_deatils
                response_object['patient_master_details'] = patientmaster_data_details

            else:
                return Response(patient_master_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        return Response(response_object, status=status.HTTP_201_CREATED)



class GetListofAllPatientMaster(APIView):
    permission_classes = (IsAuthenticated,)
    authentication_classes = (TokenAuthentication,)

    def get(self, request, *args, **kwargs):

        result_array_obj = [] 

        list_of_user = PatientMaster.objects.all().values('patient_id', 'phone_number', 'date_of_birth','gender','height',
        													   'weight','bmi','address','pincode','state_name','city_name',
                                                               'user_id', 'user_id__username', 'user_id__first_name',
                                                               'user_id__last_name', 'user_id__email',
                                                               'user_id__password', 'user_id__is_staff',
                                                               'user_id__is_superuser')

        if len(list_of_user) > 0:
            for i in range(len(list_of_user)):
                result_json_obj = {}
                result_json_obj['patient_id'] = list_of_user[i]['patient_id']
                result_json_obj['phone_number'] = list_of_user[i]['phone_number']
                result_json_obj['date_of_birth'] = list_of_user[i]['date_of_birth']
                result_json_obj['gender'] = list_of_user[i]['gender']
                result_json_obj['height'] = list_of_user[i]['height']
                result_json_obj['weight'] = list_of_user[i]['weight']
                result_json_obj['bmi'] = list_of_user[i]['bmi']
                result_json_obj['address'] = list_of_user[i]['address']
                result_json_obj['pincode'] = list_of_user[i]['pincode']
                result_json_obj['state_name'] = list_of_user[i]['state_name']
                result_json_obj['city_name'] = list_of_user[i]['city_name']
                result_json_obj['user_id'] = list_of_user[i]['user_id']
                result_json_obj['username'] = list_of_user[i]['user_id__username']
                result_json_obj['first_name'] = list_of_user[i]['user_id__first_name']
                result_json_obj['last_name'] = list_of_user[i]['user_id__last_name']
                result_json_obj['email'] = list_of_user[i]['user_id__email']
                result_json_obj['password'] = list_of_user[i]['user_id__password']
                result_json_obj['is_staff'] = list_of_user[i]['user_id__is_staff']
                result_json_obj['is_superuser'] = list_of_user[i]['user_id__is_superuser']
                
                user_group = User.objects.filter(pk=list_of_user[i]['user_id']).values('groups__name')
                if len(user_group) > 0:
                    user_group_details_array = []
                    if len(user_group) > 0:
                        for i in range(len(user_group)):
                            user_group_details_array.append(user_group[i]['groups__name'])
                        result_json_obj['group_name'] = user_group_details_array
                else:
                    result_json_obj['group_name'] = None
                result_array_obj.append(result_json_obj)
        return Response(result_array_obj)


# class UpdatePatientMasterApi(APIView):
#     permission_classes = (IsAuthenticated,)
#     authentication_classes = (TokenAuthentication,)

#     def put(self, request, employee_id, *args, **kwargs):
#         data = request.data
#         user_data = {}
#         employee_data = {}
#         response_object = {}

#         if 'username' in data['user']:
#             user_data['username'] = data['user']['username']
#         if 'first_name' in data['user']:
#             user_data['first_name'] = data['user']['first_name']
#         if 'last_name' in data['user']:
#             user_data['last_name'] = data['user']['last_name']
#         if 'email' in data['user']:
#             user_data['email'] = data['user']['email']
#         if 'is_staff' in data['user']:
#             user_data['is_staff'] = data['user']['is_staff']
#         if 'is_superuser' in data['user']:
#             user_data['is_superuser'] = data['user']['is_superuser']
#         # employee_master data
#         if 'phone_number' in data:
#             user_master_data['phone_number'] = data['phone_number']
#         if 'address_line_1' in data:
#             user_master_data['address_line_1'] = data['address_line_1']
#         if 'address_line_2' in data:
#             user_master_data['address_line_2'] = data['address_line_2']
#         if 'pincode' in data:
#             user_master_data['pincode'] = data['pincode']

#         if UserMaster.objects.filter(user_master_id=user_master_id).exists():
#             user_details = UserMaster.objects.filter(user_master_id=user_master_id).values('user').get()
#             user_id = user_details['user']
#             user_details_id = User.objects.get(id=user_id)
#             user_details_id.username = user_data['username']
#             user_details_id.first_name = user_data['first_name']
#             user_details_id.last_name = user_data['last_name']
#             user_details_id.is_staff = user_data['is_staff']
#             user_details_id.is_superuser = user_data['is_superuser']
#             user_details_id.save()
#             id = user_details_id.id
#             user_name = user_details_id.username
#             if 'password' in data:
#                 password = data['password']
#                 user_set_password = User.objects.get(username=user_name)
#                 user_set_password.set_password(password)
#                 user_set_password.save()
#             user_master_data['user'] = id
#             user_master_details_id = UserMaster.objects.get(user=id)
#             final_user_data = User.objects.filter(username=user_name).values().get()
#             user_master_serializer = PatientMasterSerializer(user_master_details_id, data=user_master_data)
#             if user_master_serializer.is_valid():
#                 user_master_serializer.save()
#                 response_object['user_master_details'] = user_master_serializer.data
#                 response_object['user_master_details']['user'] = final_user_data
#                 return Response(response_object, status=status.HTTP_201_CREATED)
#             else:
#                 return Response(user_master_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response("User with this id doesn't exists, Please Select valid User Id",
#                             status=status.HTTP_200_OK)