# Register your models here.
from django.contrib import admin
from .models import *


@admin.register(PatientMedical)
class PatientMedicalAdmin(admin.ModelAdmin):
    list_display = (
    'patient_medical_id', 'patient_id', 'diagnosis_id', 'is_active', 'created_by', 'modified_by', 'created_date',
    'modified_date', 'deactivation_reason', 'is_suspended', 'suspension_reason', 'is_audit_required')
    ordering = ['patient_medical_id']
    search_fields = ('patient_medical_id', 'patient_id', 'diagnosis_id', 'created_by', 'modified_by')
    list_display_links = (
   'patient_medical_id', 'patient_id', 'diagnosis_id', 'is_active', 'deactivation_reason', 'is_suspended',
    'suspension_reason', 'is_audit_required', 'created_by', 'modified_by')
    fieldsets = (
        ('Patient Diagnosis', {
            'fields': (
           'patient_id', 'diagnosis_id', 'is_active', 'deactivation_reason', 'is_suspended', 'suspension_reason',
            'is_audit_required', 'created_by', 'modified_by')
        }),
    )
    list_per_page = 25




@admin.register(PatientWeight)
class PatientWeightAdmin(admin.ModelAdmin):
    list_display = (
    'patient_weight_id', 'patient_id', 'weight', 'height', 'bmi', 'is_active', 'created_by', 'modified_by', 'created_date',
    'modified_date', 'deactivation_reason', 'is_suspended', 'suspension_reason', 'is_audit_required')
    ordering = ['patient_weight_id']
    search_fields = ('patient_weight_id', 'patient_id', 'weight', 'height', 'bmi', 'created_by', 'modified_by')
    list_display_links = (
   'patient_weight_id', 'patient_id', 'weight', 'height', 'bmi', 'is_active', 'deactivation_reason', 'is_suspended',
    'suspension_reason', 'is_audit_required', 'created_by', 'modified_by')
    fieldsets = (
        ('Patient Weight', {
            'fields': (
           'patient_id', 'weight', 'height', 'bmi',  'is_active', 'deactivation_reason', 'is_suspended', 'suspension_reason',
            'is_audit_required', 'created_by', 'modified_by')
        }),
    )
    list_per_page = 25


@admin.register(PatientBloodGlucose)
class PatientBloodGlucoseAdmin(admin.ModelAdmin):
    list_display = (
    'patient_blood_glucose_id', 'patient_id', 'bloodglucose', 'blood_glucose_level', 'is_active', 'created_by', 'modified_by', 'created_date',
    'modified_date', 'deactivation_reason', 'is_suspended', 'suspension_reason', 'is_audit_required')
    ordering = ['patient_blood_glucose_id']
    search_fields = ('patient_blood_glucose_id', 'patient_id', 'bloodglucose', 'blood_glucose_level', 'created_by', 'modified_by')
    list_display_links = (
   'patient_blood_glucose_id', 'patient_id', 'bloodglucose',  'blood_glucose_level', 'is_active', 'deactivation_reason', 'is_suspended',
    'suspension_reason', 'is_audit_required', 'created_by', 'modified_by')
    fieldsets = (
        ('Patient Blood Glucose', {
            'fields': (
           'patient_id', 'bloodglucose',  'blood_glucose_level', 'is_active', 'deactivation_reason', 'is_suspended', 'suspension_reason',
            'is_audit_required', 'created_by', 'modified_by')
        }),
    )
    list_per_page = 25