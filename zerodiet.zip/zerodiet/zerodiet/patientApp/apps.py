from django.apps import AppConfig


class PatientappConfig(AppConfig):
    name = 'patientApp'
