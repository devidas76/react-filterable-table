from enum import Enum


class BloodGlucose(Enum):
    fastingblood = 'Fasting Blood Glucose Level'
    postbreakfast = 'Post Breakfast Blood Glucose Level'
    prelunchblood = 'Pre Lunch Blood Glucose Level'
    postlunchblood = 'Post Lunch Blood Glucose Level'
    predinnerblood = 'Pre Dinner Blood Glucose Level'
    postdinnerblood = 'Post Dinner Blood Glucose Level'
    beforebedblood = 'Before Bed Blood Glucose Level'
    
   