from django.db import models

# Create your models here.
from django.contrib.auth.models import User
from django.core.validators import RegexValidator
from django.core.exceptions import ValidationError
from django.utils.crypto import get_random_string
from django.contrib.postgres.fields import ArrayField
from multiselectfield import MultiSelectField
#from django.contrib.auth.models import AbstractUser
# Create your models here.
from .constants import *


class Base(models.Model):
    is_active = models.BooleanField(default=True)
    deactivation_reason = models.CharField(max_length=256, blank=True, null=True, default=None)
    is_suspended = models.BooleanField(default=False)
    suspension_reason = models.CharField(max_length=256, blank=True, null=True, default=None)
    is_audit_required = models.BooleanField(default=False)
    created_by = models.CharField(max_length=200, blank=True, null=True, default=None)
    created_date = models.DateTimeField(auto_now_add=True, blank=True, null=True, editable=False)
    modified_by = models.CharField(max_length=200, blank=True, null=True, default=None)
    modified_date = models.DateTimeField(auto_now=True, blank=True, null=True, editable=False)


    class Meta:
        abstract = True

class PatientMedical(Base):
	patient_medical_id = models.CharField(max_length=16, blank=True, null=True, editable=False, unique=True)
	patient_id = models.ForeignKey(to='hrApp.PatientMaster', to_field="patient_id", on_delete=models.CASCADE,
                                        blank=False, null=True, default=None)
	diagnosis_id = models.ForeignKey(to='hrApp.DiagnosisMaster', to_field="diagnosis_id", on_delete=models.CASCADE,
                                        blank=False, null=True, default=None)

	class Meta:
		db_table = 'dt_patient_medical'
		verbose_name = "Patient Diagnosis"
		verbose_name_plural = "Patient Diagnosis"

	def save(self, **kwargs):
		if not self.patient_medical_id:
			self.patient_medical_id = get_random_string(length=6)
		super(PatientMedical, self).save(**kwargs)


class PatientWeight(Base):
	patient_weight_id = models.CharField(max_length=16, blank=True, null=True, editable=False, unique=True)
	patient_id = models.ForeignKey(to='hrApp.PatientMaster', to_field="patient_id", on_delete=models.CASCADE,
                                        blank=False, null=True, default=None)
	weight = models.CharField(max_length=16, blank=True, null=True, default=None)
	height = models.CharField(max_length=16, blank=True, null=True, default=None)
	bmi = models.CharField(max_length=16, blank=True, null=True, default=None)

	class Meta:
		db_table = 'dt_patient_weight'
		verbose_name = "Patient BMI"
		verbose_name_plural = "Patient BMI"

	def save(self, **kwargs):
		if not self.patient_weight_id:
			self.patient_weight_id = get_random_string(length=6)
		super(PatientWeight, self).save(**kwargs)


class PatientBloodGlucose(Base):
	patient_blood_glucose_id = models.CharField(max_length=16, blank=True, null=True, editable=False, unique=True)
	patient_id = models.ForeignKey(to='hrApp.PatientMaster', to_field="patient_id", on_delete=models.CASCADE,
                                        blank=False, null=True, default=None)
	Blood_Glucose = (
		(1, BloodGlucose.fastingblood.value),
		(2, BloodGlucose.postbreakfast.value),
		(3, BloodGlucose.prelunchblood.value),
		(4, BloodGlucose.postlunchblood.value),
		(5, BloodGlucose.predinnerblood.value),
		(6, BloodGlucose.postdinnerblood.value),
		(7, BloodGlucose.beforebedblood.value)
	)
	bloodglucose = models.IntegerField(choices=Blood_Glucose, blank=False, default=1)
	blood_glucose_level = models.CharField(max_length=16, blank=True, null=True, default=None)

	class Meta:
		db_table = 'dt_patient_blood_glucose'
		verbose_name = "Patient Blood Glucose"
		verbose_name_plural = "Patient Blood Glucose"

	def save(self, **kwargs):
		if not self.patient_blood_glucose_id:
			self.patient_blood_glucose_id = get_random_string(length=6)
		super(PatientBloodGlucose, self).save(**kwargs)