from .models import *
from rest_framework import serializers, fields
from django.shortcuts import get_object_or_404


class PatientMedicalSerializer(serializers.ModelSerializer):

    class Meta:
        model = PatientMedical
        fields = '__all__'

class PatientWeightSerializer(serializers.ModelSerializer):

    class Meta:
        model = PatientWeight
        fields = '__all__'


class PatientBloodGlucoseSerializer(serializers.ModelSerializer):

    class Meta:
        model = PatientBloodGlucose
        fields = '__all__'
