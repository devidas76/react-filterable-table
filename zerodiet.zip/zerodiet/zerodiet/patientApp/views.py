from django.shortcuts import render

# Create your views here.
import datetime
import os
import os.path
import socket
from collections import defaultdict

from django.conf import settings
from django.contrib.auth.models import Group
from django.contrib.auth.models import User
from django.core.files.storage import default_storage
from django.db.models import Q
from django.shortcuts import get_object_or_404
from rest_framework import generics
from rest_framework import status
from rest_framework.authentication import TokenAuthentication
from rest_framework.generics import ListAPIView, CreateAPIView, RetrieveUpdateDestroyAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import *
from .serializers import *

class PatientMedicalListAPIView(ListAPIView):
    queryset = PatientMedical.objects.all()
    serializer_class = PatientMedicalSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (TokenAuthentication,)


class PatientMedicalRetrieveAPIView(RetrieveUpdateDestroyAPIView):
    queryset = PatientMedical.objects.all()
    serializer_class = PatientMedicalSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (TokenAuthentication,)
    lookup_field = "patient_medical_id"


class PatientMedicalidRetrieveAPIView(ListAPIView):
    queryset = PatientMedical.objects.all()
    serializer_class = PatientMedicalSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (TokenAuthentication,)
    lookup_field = "patient_id"


class BookServiceCreateAPIView(CreateAPIView):
    queryset = PatientMedical.objects.all()
    serializer_class = PatientMedicalSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (TokenAuthentication,)


class PatientWeightListAPIView(ListAPIView):
    queryset = PatientWeight.objects.all()
    serializer_class = PatientWeightSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (TokenAuthentication,)


class PatientWeightRetrieveAPIView(RetrieveUpdateDestroyAPIView):
    queryset = PatientWeight.objects.all()
    serializer_class = PatientWeightSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (TokenAuthentication,)
    lookup_field = "patient_weight_id"


class PatientidRetrieveAPIView(ListAPIView):
    queryset = PatientWeight.objects.all()
    serializer_class = PatientWeightSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (TokenAuthentication,)
    lookup_field = "patient_id"


class BookServiceCreateAPIView(CreateAPIView):
    queryset = PatientWeight.objects.all()
    serializer_class = PatientWeightSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (TokenAuthentication,)


class PatientBloodGlucoseListAPIView(ListAPIView):
    queryset = PatientBloodGlucose.objects.all()
    serializer_class = PatientBloodGlucoseSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (TokenAuthentication,)


class PatientBloodGlucoseRetrieveAPIView(RetrieveUpdateDestroyAPIView):
    queryset = PatientBloodGlucose.objects.all()
    serializer_class = PatientBloodGlucoseSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (TokenAuthentication,)
    lookup_field = "patient_weight_id"


class PatientBloodGlucoseidRetrieveAPIView(ListAPIView):
    queryset = PatientBloodGlucose.objects.all()
    serializer_class = PatientBloodGlucoseSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (TokenAuthentication,)
    lookup_field = "patient_id"


class BookServiceCreateAPIView(CreateAPIView):
    queryset = PatientBloodGlucose.objects.all()
    serializer_class = PatientBloodGlucoseSerializer
    permission_classes = (IsAuthenticated,)
    authentication_classes = (TokenAuthentication,)
